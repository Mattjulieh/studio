import { config } from 'dotenv';
config();

import '@/ai/flows/match-recommendations.ts';